import { useCallback, useRef, useState } from 'react'
import { audioUrl } from '../services/api.js'

export function useAudioAvatar() {
  const [amplitude, setAmplitude] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const audioRef = useRef(null)
  const audioContextRef = useRef(null)
  const objectUrlRef = useRef(null)
  const animationFrameRef = useRef(null)

  const stopAudio = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = null
    }

    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.src = ''
      audioRef.current = null
    }

    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current)
      objectUrlRef.current = null
    }

    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {})
      audioContextRef.current = null
    }

    setAmplitude(0)
    setIsPlaying(false)
  }, [])

  const playAudio = useCallback(async (pathOrFile, onEnded) => {
    stopAudio()

    const finalUrl = pathOrFile instanceof Blob
      ? URL.createObjectURL(pathOrFile)
      : audioUrl(pathOrFile)
    if (!finalUrl) {
      setIsPlaying(false)
      return
    }
    if (pathOrFile instanceof Blob) objectUrlRef.current = finalUrl

    const audio = new Audio(finalUrl)
    audio.crossOrigin = 'anonymous'
    audioRef.current = audio

    const AudioContextClass = window.AudioContext || window.webkitAudioContext
    const audioContext = new AudioContextClass()
    audioContextRef.current = audioContext
    const source = audioContext.createMediaElementSource(audio)
    const analyser = audioContext.createAnalyser()
    analyser.fftSize = 256
    source.connect(analyser)
    analyser.connect(audioContext.destination)

    const dataArray = new Uint8Array(analyser.frequencyBinCount)

    const tick = () => {
      analyser.getByteFrequencyData(dataArray)
      const average = dataArray.reduce((sum, value) => sum + value, 0) / dataArray.length
      setAmplitude(Math.min(1, average / 95))
      animationFrameRef.current = requestAnimationFrame(tick)
    }

    audio.onended = () => {
      stopAudio()
      if (onEnded) onEnded()
    }

    audio.onerror = () => {
      stopAudio()
      if (onEnded) onEnded(new Error('This browser cannot play the selected audio format.'))
    }

    setIsPlaying(true)
    try {
      await audio.play()
    } catch {
      stopAudio()
      throw new Error('This browser cannot play the selected audio format. Try MP3, WAV, M4A, or WebM.')
    }
    tick()
  }, [stopAudio])

  return {
    amplitude,
    isPlaying,
    playAudio,
    stopAudio,
  }
}
