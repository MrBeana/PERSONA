const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'
const TRANSCRIPTION_FORMATS = /\.(mp3|mp4|mpeg|mpga|m4a|wav|webm)$/i

async function toTranscriptionFile(file) {
  if (TRANSCRIPTION_FORMATS.test(file.name)) return file

  const AudioContextClass = window.AudioContext || window.webkitAudioContext
  if (!AudioContextClass) throw new Error('This browser cannot convert the selected audio format.')

  const context = new AudioContextClass()
  try {
    const source = await context.decodeAudioData(await file.arrayBuffer())
    const sampleRate = 16000
    const ratio = source.sampleRate / sampleRate
    const length = Math.ceil(source.length / ratio)
    const samples = new Float32Array(length)

    for (let index = 0; index < length; index += 1) {
      const sourceIndex = Math.min(source.length - 1, Math.floor(index * ratio))
      let sample = 0
      for (let channel = 0; channel < source.numberOfChannels; channel += 1) {
        sample += source.getChannelData(channel)[sourceIndex]
      }
      samples[index] = sample / source.numberOfChannels
    }

    const wav = new ArrayBuffer(44 + samples.length * 2)
    const view = new DataView(wav)
    const writeText = (offset, value) => {
      for (let index = 0; index < value.length; index += 1) {
        view.setUint8(offset + index, value.charCodeAt(index))
      }
    }
    writeText(0, 'RIFF')
    view.setUint32(4, 36 + samples.length * 2, true)
    writeText(8, 'WAVE')
    writeText(12, 'fmt ')
    view.setUint32(16, 16, true)
    view.setUint16(20, 1, true)
    view.setUint16(22, 1, true)
    view.setUint32(24, sampleRate, true)
    view.setUint32(28, sampleRate * 2, true)
    view.setUint16(32, 2, true)
    view.setUint16(34, 16, true)
    writeText(36, 'data')
    view.setUint32(40, samples.length * 2, true)
    for (let index = 0; index < samples.length; index += 1) {
      const sample = Math.max(-1, Math.min(1, samples[index]))
      view.setInt16(44 + index * 2, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true)
    }

    return new File([wav], `${file.name.replace(/\.[^.]+$/, '') || 'audio'}.wav`, { type: 'audio/wav' })
  } catch {
    throw new Error('This browser could not read that audio format. Try MP3, WAV, M4A, or WebM.')
  } finally {
    await context.close()
  }
}

export function audioUrl(path) {
  if (!path) return null
  if (path.startsWith('http')) return path
  return `${API_BASE}${path}`
}

export async function fetchPersonas() {
  const response = await fetch(`${API_BASE}/api/personas`)
  if (!response.ok) {
    throw new Error(`Could not load personas: ${response.status}`)
  }
  return response.json()
}

export async function sendChat({ message, personaId, includeAudio = true }) {
  const response = await fetch(`${API_BASE}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message,
      persona_id: personaId,
      include_audio: includeAudio,
    }),
  })

  const payload = await response.json()
  if (!response.ok) {
    throw new Error(payload.detail || `Chat request failed: ${response.status}`)
  }
  return payload
}

export async function transcribeAudio(file) {
  const formData = new FormData()
  const transcriptionFile = await toTranscriptionFile(file)
  formData.append('file', transcriptionFile, transcriptionFile.name || 'audio.webm')

  const response = await fetch(`${API_BASE}/api/transcribe`, {
    method: 'POST',
    body: formData,
  })

  const payload = await response.json()
  if (!response.ok) {
    throw new Error(payload.detail || `Transcription failed: ${response.status}`)
  }
  return payload
}
