import { useRef, useState } from 'react'

export default function VoiceRecorder({ onAudioReady, disabled }) {
  const [isRecording, setIsRecording] = useState(false)
  const [selectedFile, setSelectedFile] = useState(null)
  const recorderRef = useRef(null)
  const chunksRef = useRef([])
  const fileInputRef = useRef(null)

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mimeType = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4']
        .find((type) => MediaRecorder.isTypeSupported(type))
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
      recorderRef.current = recorder
      chunksRef.current = []

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data)
      }

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' })
        const extension = blob.type.includes('mp4') ? 'm4a' : 'webm'
        const file = new File([blob], `classroom_recording.${extension}`, { type: blob.type })
        stream.getTracks().forEach((track) => track.stop())
        onAudioReady(file)
      }

      recorder.start()
      setIsRecording(true)
    } catch (error) {
      onAudioReady(null, error.message || 'Microphone access is unavailable.')
    }
  }

  function stopRecording() {
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop()
    }
    setIsRecording(false)
  }

  function handleFileChange(event) {
    const file = event.target.files?.[0]
    if (file) {
      if (!file.type.startsWith('audio/') && !/\.(mp3|mp4|mpeg|mpga|m4a|wav|webm|ogg|oga|flac|aac|opus|aiff?)$/i.test(file.name)) {
        onAudioReady(null, 'Choose an audio file to continue.')
        event.target.value = ''
        return
      }
      setSelectedFile(file)
      onAudioReady(file)
    }
    event.target.value = ''
  }

  return (
    <div className="recorder-row">
      {!isRecording ? (
        <button type="button" onClick={startRecording} disabled={disabled}>
          Record voice
        </button>
      ) : (
        <button type="button" onClick={stopRecording} className="secondary">
          Stop recording
        </button>
      )}
      <input
        ref={fileInputRef}
        className="audio-file-input"
        type="file"
        accept="audio/*"
        onChange={handleFileChange}
        disabled={disabled || isRecording}
        aria-label="Choose an audio file"
      />
      <button
        type="button"
        className="secondary upload-audio-button"
        onClick={() => fileInputRef.current?.click()}
        disabled={disabled || isRecording}
      >
        Add audio file
      </button>
      <span className="recorder-hint">
        {selectedFile ? `${selectedFile.name} - ${(selectedFile.size / (1024 * 1024)).toFixed(1)} MB. ` : ''}
        Choose any audio file; unsupported codecs may need browser conversion for transcription.
      </span>
    </div>
  )
}
