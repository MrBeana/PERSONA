// import { Canvas } from '@react-three/fiber'
// import ProceduralAvatar from './ProceduralAvatar.jsx'

// export default function AvatarCanvas({ state, amplitude }) {
//   return (
//     <div className="avatar-card">
//       <Canvas camera={{ position: [0, 0.15, 4], fov: 45 }}>
//         <ambientLight intensity={1.8} />
//         <directionalLight position={[3, 4, 5]} intensity={2.2} />
//         <pointLight position={[-3, -2, 4]} intensity={0.9} />
//         <ProceduralAvatar state={state} amplitude={amplitude} />
//       </Canvas>
//       <div className={`avatar-status state-${state}`}>
//         {state.toUpperCase()}
//       </div>
//     </div>
//   )
// }

import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { Environment, ContactShadows, AccumulativeShadows, RandomizedLight } from '@react-three/drei'
import ProceduralAvatar from './ProceduralAvatar.jsx'

export default function AvatarCanvas({ state, amplitude }) {
  return (
    <div className="avatar-card">
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{ position: [0, -0.1, 4.6], fov: 40 }}
        gl={{ antialias: true, toneMappingExposure: 1.1 }}
      >
        {/* soft ambient fill so shadow side never goes fully black */}
        <ambientLight intensity={0.35} />

        {/* key light - creates the primary highlight + real shadow */}
        <directionalLight
          position={[3, 4, 5]}
          intensity={1.6}
          castShadow
          shadow-mapSize={[1024, 1024]}
        />

        {/* cool rim/back light to separate the avatar from the background */}
        <pointLight position={[-3, -1.5, -3]} intensity={0.8} color="#7ea8ff" />

        {/* small fill from below-front to lift the underside a touch */}
        <pointLight position={[0, -2, 3]} intensity={0.25} color="#ffffff" />

        {/* avatar renders independently — never blocked by env/shadow loading */}
        <Suspense fallback={null}>
          <ProceduralAvatar state={state} amplitude={amplitude} />
        </Suspense>

        {/* image-based lighting in its own boundary: if the HDRI fetch hangs
            or fails, only the reflections are missing — the head still shows */}
        <Suspense fallback={null}>
          <Environment preset="studio" />
        </Suspense>

        <Suspense fallback={null}>
          <ContactShadows
            position={[0, -1.15, 0]}
            opacity={0.45}
            scale={6}
            blur={2.6}
            far={2}
          />
        </Suspense>
      </Canvas>

      <div className={`avatar-status state-${state}`}>{state.toUpperCase()}</div>
    </div>
  )
}