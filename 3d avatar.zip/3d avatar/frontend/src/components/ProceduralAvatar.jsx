import { useFrame } from '@react-three/fiber'
import { MathUtils } from 'three'
import { useRef } from 'react'

function statusColor(state) {
  if (state === 'listening') return '#5B9BD5'
  if (state === 'thinking') return '#4472C4'
  if (state === 'speaking') return '#161A3E'
  if (state === 'error') return '#C0392B'
  return '#D6E4F0'
}

function Eye({ position, blinkRef }) {
  return (
    <group position={position}>
      <group ref={blinkRef}>
        <mesh scale={[1, 0.84, 0.45]}>
          <sphereGeometry args={[0.145, 32, 24]} />
          <meshStandardMaterial color="#FFFFFF" roughness={0.3} />
        </mesh>
        <group position={[0, -0.005, 0.106]}>
          <mesh scale={[1, 1, 0.5]}>
            <sphereGeometry args={[0.083, 28, 24]} />
            <meshStandardMaterial color="#4774A8" roughness={0.27} />
          </mesh>
          <mesh position={[0, 0, 0.036]} scale={[1, 1, 0.45]}>
            <sphereGeometry args={[0.046, 24, 20]} />
            <meshStandardMaterial color="#17213D" roughness={0.2} />
          </mesh>
          <mesh position={[-0.022, 0.032, 0.06]}>
            <sphereGeometry args={[0.018, 16, 16]} />
            <meshBasicMaterial color="#FFFFFF" />
          </mesh>
        </group>
      </group>
    </group>
  )
}

export default function ProceduralAvatar({ state, amplitude }) {
  const headRef = useRef()
  const bodyRef = useRef()
  const mouthRef = useRef()
  const ringRef = useRef()
  const leftEyeRef = useRef()
  const rightEyeRef = useRef()
  const gazeRef = useRef()
  const breathRef = useRef(0)
  const mouthFormRef = useRef(0)

  useFrame(({ clock }, delta) => {
    const time = clock.getElapsedTime()
    const speaking = state === 'speaking'
    const listening = state === 'listening'
    const thinking = state === 'thinking'

    if (headRef.current) {
      const targetYaw = Math.sin(time * 0.37) * 0.055 + Math.sin(time * 0.13) * 0.025 + (thinking ? 0.12 : 0)
      const targetPitch = Math.sin(time * 0.51) * 0.023 + (listening ? -0.04 : 0)
      const speechNod = speaking ? Math.sin(time * 2.7) * 0.022 : 0
      headRef.current.rotation.y = MathUtils.damp(headRef.current.rotation.y, targetYaw, 2.5, delta)
      headRef.current.rotation.x = MathUtils.damp(headRef.current.rotation.x, targetPitch + speechNod, 2.8, delta)
      headRef.current.rotation.z = MathUtils.damp(headRef.current.rotation.z, Math.sin(time * 0.31) * 0.012, 2, delta)
      headRef.current.position.y = MathUtils.damp(
        headRef.current.position.y,
        Math.sin(time * 0.82) * 0.018 + Math.sin(time * 2.4) * (speaking ? 0.009 : 0.002),
        2.5,
        delta,
      )
    }

    if (bodyRef.current) {
      breathRef.current = Math.sin(time * 0.82) * 0.012 + (speaking ? Math.sin(time * 2.4) * 0.006 : 0)
      bodyRef.current.position.y = -1.16 + breathRef.current
      bodyRef.current.scale.y = 1 + Math.sin(time * 0.82) * 0.008
    }

    // A short, soft blink repeats at natural intervals; the offset keeps the eyes in sync.
    const blinkAt = (offset) => {
      const phase = (time + offset) % 4.6
      if (phase < 0.13) return Math.sin((phase / 0.13) * Math.PI)
      if (phase > 0.2 && phase < 0.31) return Math.sin(((phase - 0.2) / 0.11) * Math.PI) * 0.42
      return 0
    }
    if (leftEyeRef.current) leftEyeRef.current.scale.y = Math.max(0.08, 1 - blinkAt(0.3) * 0.94)
    if (rightEyeRef.current) rightEyeRef.current.scale.y = Math.max(0.08, 1 - blinkAt(0.34) * 0.94)

    if (gazeRef.current) {
      const lookX = thinking ? 0.035 : Math.sin(time * 0.29) * 0.028
      gazeRef.current.position.x = MathUtils.damp(gazeRef.current.position.x, lookX, 3, delta)
      gazeRef.current.position.y = MathUtils.damp(gazeRef.current.position.y, Math.sin(time * 0.23) * 0.012, 2, delta)
    }

    if (mouthRef.current) {
      const idleMouth = 0.095 + Math.sin(time * 0.74) * 0.008
      const mouthOpen = speaking
        ? 0.09 + Math.min(1, amplitude * 1.7) * 0.72 + Math.max(0, Math.sin(time * 8.4)) * 0.045
        : idleMouth
      mouthFormRef.current = MathUtils.damp(mouthFormRef.current, speaking ? amplitude : 0, 9, delta)
      mouthRef.current.scale.x = MathUtils.damp(mouthRef.current.scale.x, 1 + mouthFormRef.current * 0.18, 8, delta)
      mouthRef.current.scale.y = MathUtils.damp(mouthRef.current.scale.y, mouthOpen, 10, delta)
      mouthRef.current.position.y = -0.3 - mouthRef.current.scale.y * 0.035
    }

    if (ringRef.current) {
      ringRef.current.rotation.z = time * 0.45
      ringRef.current.scale.setScalar(MathUtils.damp(
        ringRef.current.scale.x,
        thinking ? 1 + Math.sin(time * 3.5) * 0.045 : listening ? 1.015 : 1,
        4,
        delta,
      ))
      ringRef.current.visible = thinking || listening
    }
  })

  return (
    <group position={[0, 0, 0]}>
      <group ref={bodyRef} position={[0, -1.16, 0]}>
        <mesh castShadow receiveShadow>
          <cylinderGeometry args={[0.72, 0.95, 0.95, 64]} />
          <meshStandardMaterial color={statusColor(state)} roughness={0.62} />
        </mesh>
        <mesh position={[0, 0.49, 0]} castShadow>
          <cylinderGeometry args={[0.39, 0.47, 0.28, 48]} />
          <meshStandardMaterial color="#C7D5E4" roughness={0.5} />
        </mesh>
      </group>

      <group ref={headRef}>
        <mesh castShadow receiveShadow>
          <sphereGeometry args={[1, 64, 64]} />
          <meshStandardMaterial color="#D6E4F0" roughness={0.48} metalness={0.02} />
        </mesh>

        <mesh position={[-0.34, 0.46, 0.83]} rotation={[0, 0, -0.08]}>
          <capsuleGeometry args={[0.035, 0.2, 6, 12]} />
          <meshStandardMaterial color="#C5D3E1" roughness={0.65} />
        </mesh>
        <mesh position={[0.34, 0.46, 0.83]} rotation={[0, 0, 0.08]}>
          <capsuleGeometry args={[0.035, 0.2, 6, 12]} />
          <meshStandardMaterial color="#C5D3E1" roughness={0.65} />
        </mesh>

        <group ref={gazeRef}>
          <Eye position={[-0.34, 0.24, 0.86]} blinkRef={leftEyeRef} />
          <Eye position={[0.34, 0.24, 0.86]} blinkRef={rightEyeRef} />
        </group>

        <group ref={mouthRef} position={[0, -0.3, 0]}>
          <mesh position={[0, 0, 0.93]} scale={[1, 1, 0.35]}>
            <sphereGeometry args={[0.26, 32, 32]} />
            <meshStandardMaterial color="#252443" roughness={0.38} />
          </mesh>
        </group>

        <mesh position={[0, -0.56, 0.79]} scale={[0.18, 0.035, 0.05]}>
          <sphereGeometry args={[1, 24, 16]} />
          <meshStandardMaterial color="#C9D6E2" roughness={0.55} />
        </mesh>

        <mesh ref={ringRef} position={[0, 0.03, 1.04]}>
          <torusGeometry args={[1.13, 0.018, 16, 96]} />
          <meshStandardMaterial color="#70A9FF" emissive="#4472C4" emissiveIntensity={0.45} />
        </mesh>
      </group>
    </group>
  )
}
