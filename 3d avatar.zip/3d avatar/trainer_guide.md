# Trainer Guide — Avatar Persona Agent Practical

## Practical goal

By the end of the build, the class should see a working browser avatar that:

1. accepts typed input or a short recorded voice clip,
2. sends the message to a persona-controlled backend,
3. generates a concise assistant response,
4. creates speech audio,
5. plays the audio in the browser,
6. animates the avatar mouth using the audio signal,
7. returns to idle after speaking.

This is a project-session build. The code package is the centerpiece; the slides should frame the architecture and decision-making.

## Recommended teaching flow

### 0–8 min — Show the final target

Run the app before explaining the files. Ask the avatar:

> Explain the avatar agent pipeline in plain language.

Point out the four visible states: idle, listening, thinking, speaking.

### 8–18 min — Architecture walk-through

Use the board or slide diagram:

```text
Browser input → FastAPI → Persona prompt → LLM → TTS → audio URL → browser playback → avatar animation
```

Emphasize that the avatar is not a decoration. It is a stateful output layer synchronized to the agent.

### 18–30 min — Environment setup

Have everyone run:

```bash
pip install -r requirements.txt
cd frontend
npm install
```

Then backend:

```bash
uvicorn backend.app:app --reload --port 8000
```

Then frontend:

```bash
npm run dev
```

Use `MOCK_MODE=true` for anyone blocked by API keys.

### 30–45 min — Backend code walk-through

Open these files in order:

1. `backend/config.py` — environment and mock mode
2. `backend/persona.py` — persona cards and prompt construction
3. `backend/agent_service.py` — LLM response generation
4. `backend/audio_service.py` — TTS and STT
5. `backend/app.py` — API routes

Main teaching point: the backend returns not only text, but also `audio_url` and `avatar_cues`.

### 45–65 min — Persona exercise

Ask the class to create a new persona in `backend/persona.py`.

Suggested persona:

```text
Name: Byte
Role: coding interview coach
Tone: crisp, direct, encouraging
Boundaries: no solving take-home exams, no false claims, explain reasoning at a high level
```

Restart the backend and verify the persona appears in the dropdown.

### 65–90 min — Frontend code walk-through

Open these files:

1. `frontend/src/App.jsx` — request lifecycle and UI state
2. `frontend/src/hooks/useAudioAvatar.js` — Web Audio amplitude extraction
3. `frontend/src/components/ProceduralAvatar.jsx` — mouth movement and state rendering
4. `frontend/src/services/api.js` — frontend/backend contract

Main teaching point: the browser is not doing AI. It is rendering state and reacting to audio.

### 90–115 min — Integration challenge

Give this task:

> Add a “demo mode” prompt button that asks the avatar to explain latency optimization.

Expected changes:

- add prompt in `samplePrompts`,
- test ask flow,
- observe `latency_ms`,
- discuss bottleneck.

### 115–135 min — Voice input test

Use the recorder. Keep clips short. The browser uploads a WebM clip to `/api/transcribe`.

If microphone issues appear, continue with typed input. The learning objective is pipeline integration, not browser audio permission debugging.

### 135–150 min — Latency discussion

Ask the class to identify delay sources:

- microphone capture,
- STT,
- LLM generation,
- TTS,
- file serving,
- browser audio decode,
- avatar playback.

Then ask which can be parallelized or streamed.

### 150–160 min — Wrap

Close with the production upgrade path:

- replace procedural avatar with GLB model,
- use viseme timing instead of amplitude,
- stream text and audio,
- add memory,
- add guardrails,
- monitor latency/cost.

## Likely student questions

### Why not start with a realistic GLB avatar?

Because asset loading, licenses, morph target names, and browser performance can derail the class. A procedural avatar teaches the pipeline reliably. GLB is the extension path.

### Is amplitude-based lip sync real lip sync?

No. It is a classroom-friendly approximation. Production lip sync maps phonemes or visemes to face shapes.

### Why use FastAPI instead of calling OpenAI directly from React?

API keys must not be exposed in browser code. The backend protects secrets, handles CORS, creates audio files, and gives a stable contract to the frontend.

### Why does the app support typed input if this is a voice/avatar session?

Typed input is the fallback that keeps the practical moving when microphone permissions or local device issues appear.

### Can this be made real-time?

Yes. The current build is request/response. A real-time version would use WebSockets/WebRTC, streaming STT, streaming LLM output, and streaming TTS or realtime audio.

### Where does persona live?

Persona lives in backend prompt construction, but it is reinforced by frontend voice, visual style, and answer length.

### Why return avatar cues from the backend?

It keeps the frontend behavior coordinated with the agent lifecycle. In production, cues could include emotion, gesture, gaze, or scene changes.

### Is OpenAI required?

No for the architecture. This package uses OpenAI for classroom simplicity. The same backend service layer can be swapped for another LLM/STT/TTS provider.

## Common errors and fixes

### `ModuleNotFoundError: backend`

Run Uvicorn from the project root:

```bash
uvicorn backend.app:app --reload --port 8000
```

Do not run it from inside the `backend/` folder.

### `OPENAI_API_KEY` missing

Use mock mode:

```bash
MOCK_MODE=true
```

Then restart the backend.

### CORS error in browser console

Ensure backend CORS allows the frontend URL. For Vite, the URL is usually:

```text
http://127.0.0.1:5173
```

### Microphone permission denied

Use typed input. Then ask learners to check browser site permissions after class.

### Audio file not found

Generated files live in `backend/generated_audio/`. Restarting the app should not delete existing files, but manually deleting the folder while the browser has an old URL can cause this.

## What to skip if running short

Skip in this order:

1. microphone recording,
2. creating a new persona,
3. latency measurement discussion,
4. GLB extension explanation.

Do not skip:

- backend route contract,
- persona prompt construction,
- TTS audio URL,
- frontend avatar state changes.

## Extension ideas for advanced learners

1. GLB avatar with morph target controls.
2. Viseme timeline generated from speech marks or a phoneme model.
3. WebSocket endpoint for streaming state updates.
4. Conversation memory summarized every few turns.
5. Guardrail service that checks persona consistency.
6. Latency dashboard showing STT/LLM/TTS timing separately.
7. ElevenLabs voice swap for expressive persona design.
8. LiveKit/WebRTC version for realtime agent conversations.

## Demo timing

The full reliable demo can fit in 20 minutes:

- 3 min: start backend and frontend
- 2 min: health check
- 5 min: typed prompt flow
- 5 min: persona dropdown and mock mode explanation
- 5 min: code walk-through of the state transition
